#!/bin/bash
python sudo.py
